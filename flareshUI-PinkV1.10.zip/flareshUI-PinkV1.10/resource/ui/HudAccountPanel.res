"Resource/UI/HudAccountPanel.res"
{
	"CHudAccountPanel"
	{
		"delta_item_x"			"77"
		"delta_item_start_y"	"5"
		"delta_item_end_y"		"5"
		"PositiveColor"			"22 182 71 125"
		"NegativeColor"			"245 54 64 125"
		"zpos"			        "-1"
		"delta_lifetime"		"0.5"
		"delta_item_font"		"CodePro13"
		"textAlignment"			"center"
	}

    //Metal Text
	"AccountValue"
	{
		"ControlName"	"CExLabel"
		"fieldName"		"AccountValue"
		"xpos"			"9"
		"ypos"			"-5"
		"zpos"			"2"
		"wide"			"100"
		"tall"			"34"
		"autoResize"	"1"
		"pinCorner"		"2"
		"visible"		"1"
		"enabled"		"1"
		"tabPosition"	"0"
		"labelText"		"%metal%"
		"textAlignment"	"center"
		"dulltext"		"0"
		"brighttext"	"0"
		"fgcolor"		"255 255 255 125"
		"font"			"CodePro20"
	}
	
	//Metal Text shadow
	"AccountValueShadow"
	{
		"ControlName"	"CExLabel"
		"fieldName"		"AccountValueShadow"
		"xpos"			"1"
		"ypos"			"-1"
		"zpos"			"2"
		"wide"			"100"
		"tall"			"34"
		"autoResize"	"1"
		"pinCorner"		"2"
		"visible"		"1"
		"enabled"		"1"
		"tabPosition"	"0"
		"labelText"		"%metal%"
		"textAlignment"	"center"
		"dulltext"		"0"
		"brighttext"	"0"
		"fgcolor"		"0 0 0 125"
		"font"			"CodePro20"
		
		"pin_to_sibling" 			"AccountValue"
		"pin_corner_to_sibling" 	"1"
		"pin_to_sibling_corner" 	"1"
	}
}