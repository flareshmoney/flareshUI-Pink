"Resource/UI/HudObjectivePlayerDestruction.res"
{	
	"ObjectiveStatusRobotDestruction"
	{
		"ControlName"		"EditablePanel"
		"fieldName"			"ObjectiveStatusRobotDestruction"
		"xpos"				"0"
		"ypos"				"-40"
		"zpos"				"1"
		"wide"				"f0"
		"tall"				"480"
		"visible"			"1"
		"enabled"			"1"

		"left_steal_edge_offset"	"97"
		"right_steal_edge_offset"	"97"
		"robot_x_offset"		"78"
		"robot_y_offset"		"47"
		"robot_x_step"			"23"
		"robot_y_step"			"0"
		

		"color_blue"			"84 111 127 255"
		"color_red"				"171 59 59 255"
	}	

	"ScoreContainer"
	{
		"fieldName"				"ScoreContainer"
		"ControlName"			"EditablePanel"
		"xpos"					"c-250"
		"ypos"					"r531"
		"zpos"					"0"
		"wide"					"400"
		"tall"					"120"
		"scaleimage"			"0"
		"visible"				"1"
		"enabled"				"1"

		"BlueScoreValueContainer"
		{
			"ControlName"		"EditablePanel"
			"fieldName"			"BlueScoreValueContainer"
			"xpos"				"c-68"
			"ypos"				"r46"
			"zpos"				"10"
			"wide"				"160"
			"tall"				"60"
			"visible"			"1"
			"enabled"			"1"
			"bgcolor_override"		"0 0 0 0"
			"proportionalToParent"	"1"

			"Score"  //Blue score
			{
				"ControlName"	"CExLabel"
				"fieldName"		"Score"
				"xpos"			"0"
				"ypos"			"c-10"
				"zpos"			"8"
				"wide"			"100"
				"tall"			"35"
				"visible"		"1"
				"enabled"		"1"
				"textAlignment"	"east"	
				"labelText"		"%score%"
				"font"			"CodePro20"
				"fgcolor"		"18 127 220 255"		
				"proportionalToParent"	"1"
			}	
		
			"ScoreShadow"  //Blue score shadow
			{
				"ControlName"	"CExLabel"
				"fieldName"		"ScoreShadow"
				"xpos"			"-1"
				"ypos"			"-1"
				"zpos"			"7"
				"wide"			"100"
				"tall"			"35"
				"visible"		"1"
				"enabled"		"1"
				"textAlignment"	"east"	
				"labelText"		"%score%"
				"font"			"CodePro20"
				"fgcolor"		"Black"		
				"proportionalToParent"	"1"
				
				"pin_to_sibling"		"Score"
				"pin_corner_to_sibling"	"PIN_TOPLEFT"
				"pin_to_sibling_corner"	"PIN_TOPLEFT"
			}
		}

		"RedScoreValueContainer"
		{
			"ControlName"		"EditablePanel"
			"fieldName"			"RedScoreValueContainer"
			"xpos"				"r136"
			"ypos"				"r46"
			"zpos"				"10"
			"wide"				"160"
			"tall"				"60"
			"visible"			"1"
			"enabled"			"1"
			"bgcolor_override"		"0 0 0 0"
			"proportionalToParent"	"1"

			"RedScore"  //red score
			{
				"ControlName"	"CExLabel"
				"fieldName"		"RedScore"
				"xpos"			"c-74"
				"ypos"			"c-10"
				"zpos"			"8"
				"wide"			"100"
				"tall"			"35"
				"visible"		"1"
				"enabled"		"1"
				"textAlignment"	"west"	
				"labelText"		"%score%"
				"font"			"CodePro20"
				"fgcolor"		"245 54 64 255"	
				"proportionalToParent"	"1"	
			}	
		
			"RedScoreShadow"  //red score shadow
			{
				"ControlName"	"CExLabel"
				"fieldName"		"RedScoreShadow"
				"xpos"			"-1"
				"ypos"			"-1"
				"zpos"			"7"
				"wide"			"100"
				"tall"			"35"
				"visible"		"1"
				"enabled"		"1"
				"textAlignment"	"west"	
				"labelText"		"%score%"
				"font"			"CodePro20"
				"fgcolor"		"Black"		
				"proportionalToParent"	"1"
				
				"pin_to_sibling"		"RedScore"
				"pin_corner_to_sibling"	"PIN_TOPLEFT"
				"pin_to_sibling_corner"	"PIN_TOPLEFT"
			}
		}
}