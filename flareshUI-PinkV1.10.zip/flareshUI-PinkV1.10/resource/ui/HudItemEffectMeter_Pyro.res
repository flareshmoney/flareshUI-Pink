#base "HudItemEffectMeter.res"

//phlog meter
"Resource/UI/HudItemEffectMeter_Pyro.res"
{
	HudItemEffectMeter
	{
		"ypos"			"r130"
	}
	
			    //Markers
	"ItemEffectMeter25"
	{
		"ControlName"	"ImagePanel"
		"fieldName"	"ItemEffectMeter25"
		"xpos"		"24"
		"ypos"		"5"
		"zpos"		"5"
		"wide"		"2"
		"tall"		"4"
		"visible"	"0"
		"enabled"	"0"
		"fillcolor"	"0 0 0 225"
	}

	"ItemEffectMeter50"
	{
		"ControlName"	"ImagePanel"
		"fieldName"	"ItemEffectMeter50"
		"xpos"		"39"
		"ypos"		"5"
		"zpos"		"3"
		"wide"		"2"
		"tall"		"4"
		"visible"	"0"
		"enabled"	"0"
		"fillcolor"	"0 0 0 225"
	}

	"ItemEffectMeter75"
	{
		"ControlName"	"ImagePanel"
		"fieldName"	"ItemEffectMeter75"
		"xpos"		"54"
		"ypos"		"5"
		"zpos"		"3"
		"wide"		"2"
		"tall"		"4"
		"visible"	"0"
		"enabled"	"0"
		"fillcolor"	"0 0 0 225"
	}
}