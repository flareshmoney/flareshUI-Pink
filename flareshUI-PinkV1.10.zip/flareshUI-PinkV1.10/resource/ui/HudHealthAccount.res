"Resource/UI/HudHealthAccount.res"
{
	"CHealthAccountPanel"
	{
		"fieldName"				"CHealthAccountPanel"
		"delta_item_x"			"180"
		"delta_item_start_y"	"0"
		"delta_item_end_y"		"0"
		"PositiveColor"			"Green"
		"NegativeColor"			"Red"
		"delta_lifetime"		"0.5"
		"delta_item_font"		"CodePro13"
	}
}